import Link from "next/link";
import PromoCarousel from "@/components/PromoCarousel";

const categories = [
  { title: "Invitation", sub: "Cards", href: "/print-products?category=Invitation%20Cards" },
  { title: "Thamboola", sub: "Bags", href: "/print-products?category=Thamboola%20Bags" },
  { title: "Business", sub: "Essentials", href: "/print-products?category=Business%20Essentials" },
  { title: "Event/Function", sub: "Essentials", href: "/print-products?category=Event%2FFunction%20Essentials" },
  { title: "Digital", sub: "Promo", href: "/print-products?category=Digital%20Promo" },
  { title: "Custom Printing", sub: "Solutions", href: "/print-products?category=Custom%20Printing%20Solutions" },
];

const reasons = [
  {
    title: "QUALITY FIRST",
    text: "Premium-quality printing with sharp detail and professional finishing.",
  },
  {
    title: "ONE-STOP SOLUTION",
    text: "From creative design to printing and finishing, everything is handled seamlessly.",
  },
  {
    title: "BUILT FOR YOUR BRAND",
    text: "Business cards, invitations, brochures, packaging and promotional prints tailored to your brand.",
  },
  {
    title: "ANY SIZE. ANY QUANTITY.",
    text: "Whether you need a small urgent order or a large production run, we scale with you.",
  },
];

export default function Home() {
  return (
    <>
      <section className="hero">
        <div className="container heroGrid">
          <div className="heroCopy">
            <div>
              <div className="tagline">
                <span className="taglineMain">Creative Prints</span>
                <span className="taglineDivider">|</span>
                <span className="taglineSub">Brand Promotion Experts</span>
              </div>
              <h1>Ideas into <span>stunning print.</span></h1>
              <p>
                JO Enterprises is your complete printing partner for high-quality custom
                printing, branding, invitations, stationery and promotional materials.
              </p>
              <div className="buttons">
                <Link className="btn primary" href="/contact">Request a Quote</Link>
                <a className="btn secondary" href="https://wa.me/919445573457">WhatsApp Us</a>
              </div>
            </div>
          </div>
          <div className="heroMedia"><PromoCarousel /></div>
        </div>
      </section>

      <section className="categorySection" aria-label="Our printing solutions">
        <div className="container">
          <div className="categoryGrid">
            {categories.map((category) => (
              <Link className="categoryItem" href={category.href} key={category.title}>
                <span>{category.title}</span>
                <strong>{category.sub}</strong>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className="brandStatement">
        <div className="container">
          <div className="brandStatementTag">
            <span className="sparkle sparkleOne">✦</span>
            <span className="sparkle sparkleTwo">✧</span>
            <p>
              <span>நாங்க வெறும் பிரிண்டிங் மட்டும் செய்யல..</span>
              <span>உங்க ஐடியாவை அடுத்த லெவலுக்குக் கொண்டு போகும்</span>
              <span className="goldText">பிராண்ட் அடையாளத்தை உருவாக்குகிறோம்!</span>
              <em>🤝 Beyond Printing, Building Brands.</em>
            </p>
            <span className="sparkle sparkleThree">✦</span>
          </div>
        </div>
      </section>

      <section className="section whySection">
        <div className="container">
          <div className="whyHeader">
            <span className="eyebrow">WHY CHOOSE JO ENTERPRISES?</span>
            <h2>Printing that puts your brand first.</h2>
          </div>

          <div className="whyGrid">
            {reasons.map((reason, index) => (
              <article className="whyCard" key={reason.title}>
                <span className="whyNumber">0{index + 1}</span>
                <h3>{reason.title}</h3>
                <p>{reason.text}</p>
              </article>
            ))}
          </div>

          <div className="trustCaption">Trusted Printing &amp; Branding Partner</div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="sectionHead">
            <span className="eyebrow">How it works</span>
            <h2>From idea to delivery</h2>
          </div>
          <div className="workflow">
            {["Enquiry","Quote","Input Collection","Design","Approval","Prepress","Printing","Finishing","Quality Check","Ready for Dispatch","Delivery","Repeat Order"].map((s,i)=>
              <div className="step" key={s}>
                <b>{i+1}. {s}</b>
                <span>{["Tell us your requirement.","Receive a competitive quotation.","Share content, logos, photos and specifications.","Our creative team prepares artwork.","Review and approve the proof.","Artwork verification and production setup.","High-quality digital or offset printing.","Lamination, cutting, binding, foiling, embossing and packing.","Every product is inspected.","Packed and prepared for shipment.","Delivered safely and on time.","Quick reordering with saved artwork and specifications."][i]}</span>
              </div>
            )}
          </div>
        </div>
      </section>

      <section className="reviewsSection" aria-label="Customer reviews">
        <div className="container">
          <div className="reviewsHeader">
            <div>
              <span className="eyebrow">Google Reviews</span>
              <h2>What our customers say</h2>
              <p>Real customer feedback, presented in a clean review-card layout.</p>
            </div>
            <a className="googleReviewBtn" href="https://www.google.com/search?q=joenterprise+google+review" target="_blank" rel="noreferrer">
              <span className="googleG">G</span> View all reviews ↗
            </a>
          </div>

          <div className="reviewCards">
            <article className="reviewCard reviewSnapCard">
              <div className="reviewTop"><span className="reviewAvatar">G</span><div><strong>Google customer review</strong><span>Verified on Google</span></div><b>★★★★★</b></div>
              <div className="reviewSnapFrame"><div className="reviewSnapInner"><span className="snapIcon">★</span><strong>4.9 / 5</strong><small>Google rating for JO Enterprises</small><em>Open the original Google review page to see the latest customer reviews.</em></div></div>
              <a href="https://www.google.com/search?q=joenterprise+google+review" target="_blank" rel="noreferrer" className="reviewLink">See original review ↗</a>
            </article>
            <article className="reviewCard reviewSnapCard">
              <div className="reviewTop"><span className="reviewAvatar">G</span><div><strong>Customer feedback</strong><span>Google Reviews</span></div><b>★★★★★</b></div>
              <div className="reviewSnapFrame"><div className="reviewSnapInner"><span className="quoteMark">“</span><strong>Trusted printing partner</strong><small>Quality • Service • Finishing</small><em>Review content is intentionally not recreated here so customer words remain authentic.</em></div></div>
              <a href="https://www.google.com/search?q=joenterprise+google+review" target="_blank" rel="noreferrer" className="reviewLink">See original review ↗</a>
            </article>
            <article className="reviewCard reviewSnapCard">
              <div className="reviewTop"><span className="reviewAvatar">G</span><div><strong>Customer feedback</strong><span>Google Reviews</span></div><b>★★★★★</b></div>
              <div className="reviewSnapFrame"><div className="reviewSnapInner"><span className="snapIcon">✓</span><strong>Real customer experiences</strong><small>Printing &amp; branding services</small><em>Use your actual Google review screenshot here for a true review snap.</em></div></div>
              <a href="https://www.google.com/search?q=joenterprise+google+review" target="_blank" rel="noreferrer" className="reviewLink">See original review ↗</a>
            </article>
          </div>
        </div>
      </section>

      <section className="statsSection" aria-label="JO Enterprises achievements">
        <div className="container">
          <div className="statsHeader">
            <span className="eyebrow">Our Numbers</span>
            <h2>Trusted by customers. Proven by results.</h2>
          </div>
          <div className="statsGrid">
            <div className="statCard">
              <span className="statIcon" aria-hidden="true">♡</span>
              <strong>359+</strong>
              <span className="statLabel">Happy Customers and counting</span>
            </div>
            <div className="statCard">
              <span className="statIcon" aria-hidden="true">✦</span>
              <strong>1,260+</strong>
              <span className="statLabel">Concept to Print Success Stories</span>
            </div>
            <div className="statCard">
              <span className="statIcon" aria-hidden="true">♜</span>
              <strong>5+</strong>
              <span className="statLabel">Years of Excellence</span>
            </div>
            <div className="statCard ratingCard">
              <span className="statIcon" aria-hidden="true">★</span>
              <strong>4.9/5</strong>
              <span className="statLabel">Google Rating</span>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
