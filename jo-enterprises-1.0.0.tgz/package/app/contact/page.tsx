"use client";

import { useState } from "react";

export default function InquiryForm({
  product = "",
}: {
  product?: string;
}) {
  const [state, setState] = useState<
    "idle" | "loading" | "done" | "error"
  >("idle");

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();

    setState("loading");

    try {
      const data = Object.fromEntries(
        new FormData(e.currentTarget)
      );

      const response = await fetch("/api/inquiries", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        setState("error");
        return;
      }

      setState("done");
      e.currentTarget.reset();
    } catch {
      setState("error");
    }
  }

  return (
    <form className="form" onSubmit={submit}>
      {state === "done" && (
        <div className="notice">
          Thank you. Your enquiry has been received.
          We&apos;ll contact you shortly.
        </div>
      )}

      {state === "error" && (
        <div className="notice">
          Something went wrong. Please use WhatsApp or phone.
        </div>
      )}

      <div className="formGrid">
        <input
          name="name"
          placeholder="Your name"
          required
        />

        <input
          name="phone"
          placeholder="Phone / WhatsApp"
          required
        />
      </div>

      <div className="formGrid">
        <input
          name="email"
          type="email"
          placeholder="Email (optional)"
        />

        <input
          name="product"
          defaultValue={product}
          placeholder="Product / service"
        />
      </div>

      <div className="formGrid">
        <input
          name="quantity"
          placeholder="Quantity / size"
        />

        <select name="budget" defaultValue="">
          <option value="">
            Budget range (optional)
          </option>

          <option value="Under ₹5,000">
            Under ₹5,000
          </option>

          <option value="₹5,000–₹15,000">
            ₹5,000–₹15,000
          </option>

          <option value="₹15,000–₹50,000">
            ₹15,000–₹50,000
          </option>

          <option value="₹50,000+">
            ₹50,000+
          </option>
        </select>
      </div>

      <textarea
        name="message"
        placeholder="Tell us what you need, including size, paper, finishing, delivery date, etc."
      />

      <button
        className="btn primary"
        type="submit"
        disabled={state === "loading"}
      >
        {state === "loading"
          ? "Sending..."
          : "Send Enquiry"}
      </button>
    </form>
  );
}