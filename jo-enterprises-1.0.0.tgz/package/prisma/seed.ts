import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

const products = [
  ["business-cards","Business Cards","Regular and premium business cards with gloss/matt lamination, synthetic stocks, foils, texture, Spot UV and specialty boards.","https://lh3.googleusercontent.com/sitesv/AG8ngQVKBIU3lrZrFSuE9MhRZFiwFfo2lrv5KVBFF8e8mz8FaVT6g11DrBy4O9ptmZHqLiDCmEmbmXzARf1xA0jx5Rabd84zsLPdDX4Ce8MVr-eILhY578pF1v51ccXZni2wgV6j86cUYKryoPcoNFyT3eKW0JQrAHOvHGUFmwJsF1Gc9X-sQ27NxZ_EZkREUnYXnlBmSG4wfb7gSA7qWL_Ts5DnYuYDwl3KRicqkwIz%3Dw1280","Business Printing",true],
  ["letterheads","Letter Heads","A4 and Letter size letterheads in one-colour, two-colour or multicolour printing on your desired paper.","https://lh3.googleusercontent.com/sitesv/AG8ngQVT2xOKm0oLgdVuWU1bbFJ2LKRb6otyJ1WWG5tsc7Jd0GpSKMBe4fdfi8fvm5xWsPlAzh5qRYqr7Un1mX7qJYgohSDNT1jY78B0maNIsi6ynIWAGj3WJCUNeYs9_b7XYaaxLX9l_sXma-UiEcHhBqZrB9ZepnKTBsL8i4v3rjXiz4gk3Jo_eZXHdpqlue2RhOpN0C52wv9shrgLinHWxNH61kHPh7bkpNh98Ghw%3Dw1280","Business Printing",true],
  ["bill-books","Bill Books","Custom duplicate/triplicate bill books and business stationery prepared to your required format.","/images/placeholder.svg","Business Printing",false],
  ["envelopes","Envelopes","Branded envelopes in standard and custom formats for professional correspondence.","/images/placeholder.svg","Business Printing",false],
  ["vouchers-receipts","Voucher / Receipt","Custom vouchers, receipts and accounting stationery for businesses.","/images/placeholder.svg","Business Printing",false],
  ["files","Files","Printed office files and presentation folders for organised business documentation.","/images/placeholder.svg","Business Printing",false],
  ["wall-posters","Wall Posters","Large-format posters for branding, announcements, campaigns and promotions.","/images/placeholder.svg","Promotional",true],
  ["flyers-brochures","Flyers / Brochures","Promotional flyers and brochures designed for clear, vibrant communication.","/images/placeholder.svg","Promotional",true],
  ["stickers","Stickers","Custom stickers and labels in a variety of shapes, finishes and sizes.","/images/placeholder.svg","Labels & Packaging",false],
  ["box-paper-bags","Box / Paper Bags","Custom printed boxes and paper bags for product presentation and retail branding.","/images/placeholder.svg","Labels & Packaging",true],
  ["calendars","Calendars","Branded calendars for promotional distribution and corporate gifting.","/images/placeholder.svg","Promotional",false],
  ["non-woven-bags","Non Woven Bags","Reusable non-woven carry bags with custom branding.","/images/placeholder.svg","Promotional",false],
  ["woven-labels","Woven Labels","Custom woven labels for apparel and textile branding.","/images/placeholder.svg","Labels & Packaging",false],
  ["novelties","Novelties","Custom promotional novelties and branded merchandise.","/images/placeholder.svg","Promotional",false],
  ["graphic-design","Graphic Design","Creative artwork, layouts and production-ready design support.","/images/placeholder.svg","Design",true],
  ["invitations","Invitations","Basic and premium invitations with single cards, pouches, Spot UV, 3D lamination, gold foil, die cuts and paper/board sets.","https://lh3.googleusercontent.com/sitesv/AG8ngQVuunUd_FV-cbMA_rWfY1TnJ3q5NxPEJQKvrWX6WNg_Y-pMQY9MNjT9FobvkDofd2l1hkYc4wFipqP2Cm0p0aGWQxmZu5dQvPGbQLqTTBKlKbowoqm5w3BmwhVb8vEcqdgaHt_Ipz_na5l7WVeGkTr_3QFXdqE3ed1jvurpg3al3RU7sePCi3t1L-wFgNOes-YPOxpKHMd9X3ZbtKdmh3H4BFV7YAGSd8LdatrSPCU%3Dw1280","Invitations",true]
];

async function main() {
  for (const p of products) {
    await prisma.product.upsert({
      where: { slug: p[0] as string },
      update: { name:p[1] as string, description:p[2] as string, image:p[3] as string, category:p[4] as string, featured:p[5] as boolean },
      create: { slug:p[0] as string, name:p[1] as string, description:p[2] as string, image:p[3] as string, category:p[4] as string, featured:p[5] as boolean }
    });
  }
}
main().finally(() => prisma.$disconnect());