"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import Link from "next/link";

const promos = [
  { image: "/images/promos/calendar-2027.svg", title: "Calendar 2027", subtitle: "Orders open now", href: "/contact" },
  { image: "/images/promos/combo-offers.svg", title: "Combo Offers", subtitle: "Smart print bundles for your business", href: "/contact" },
  { image: "/images/promos/eco-paper-bags.svg", title: "Eco-Friendly Paper Bags", subtitle: "Sustainable packaging with your brand", href: "/contact" },
  { image: "/images/promos/seasonal-promos.svg", title: "Special Promos", subtitle: "Limited-time printing offers", href: "/contact" },
];

export default function PromoCarousel() {
  const [active, setActive] = useState(0);

  useEffect(() => {
    const timer = window.setInterval(() => setActive((current) => (current + 1) % promos.length), 4500);
    return () => window.clearInterval(timer);
  }, []);

  return (
    <div className="promoCarousel" aria-label="Current offers and promotions">
      <div className="promoViewport">
        {promos.map((promo, index) => (
          <div className={`promoSlide ${index === active ? "isActive" : ""}`} key={promo.title}>
            <Image src={promo.image} alt={`${promo.title} - ${promo.subtitle}`} fill sizes="(max-width: 850px) 92vw, 52vw" priority={index === 0} />
            <div className="promoOverlay">
              <span className="promoLabel">JO ENTERPRISES • FEATURED</span>
              <h2>{promo.title}</h2>
              <p>{promo.subtitle}</p>
              <Link className="promoCta" href={promo.href}>Enquire now <span>→</span></Link>
            </div>
          </div>
        ))}
      </div>
      <div className="promoControls">
        <div className="promoDots">
          {promos.map((promo, index) => (
            <button key={promo.title} aria-label={`Show ${promo.title}`} aria-pressed={index === active} className={index === active ? "active" : ""} onClick={() => setActive(index)} />
          ))}
        </div>
        <span className="promoHint">Auto display • click to explore</span>
      </div>
    </div>
  );
}
