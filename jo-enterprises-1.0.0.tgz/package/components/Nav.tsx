import Link from "next/link";

export default function Nav() {
  return (
    <nav className="nav">
      <div className="container navin">

        <Link href="/" className="brand" aria-label="JO Enterprises - Print Solutions">
          <img
            src="/images/Logo.png"
            alt="JO Enterprises logo"
            className="logo"
          />
          <span className="brandText">
            <span className="brandTitle">JO Enterprises</span>
            <span className="brandSubtitle">Print Solutions</span>
          </span>
        </Link>

        <div className="links">
          <Link href="/">Home</Link>
          <Link href="/print-products">Print Products</Link>
          <Link href="/e-cards">E-Cards</Link>
          <Link href="/gallery">Gallery</Link>
          <Link href="/contact">Contact</Link>
          <Link className="cta" href="/contact">
            Get a Quote
          </Link>
        </div>

      </div>
    </nav>
  );
}