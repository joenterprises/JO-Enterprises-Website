export default function Footer(){return <footer className="footer"><div className="container footerGrid">
<img
  src="/images/logo.png"
  alt="JO Enterprises"
  className="footerLogo"
/>
<div><h2>JO Enterprises</h2><p>Your complete printing partner — creative design, premium printing, invitations, business stationery and promotional products.</p></div>
<div><h3>Locations</h3><p>Printing Hub: Sivakasi<br/>Design Desk: Muhavoor</p></div>
<div><h3>Connect</h3><p><a href="https://wa.me/919445573457">WhatsApp</a><br/><a href="https://www.instagram.com/joenterprises.am/">Instagram</a><br/><a href="https://www.youtube.com/@joenterprises_am">YouTube</a></p></div>
</div></footer>}