"use client";
import {useState} from "react";
export default function InquiryForm({product=""}:{product?:string}){const [state,setState]=useState("idle");
async function submit(e:React.FormEvent<HTMLFormElement>){e.preventDefault();setState("loading");const data=Object.fromEntries(new FormData(e.currentTarget));const r=await fetch("/api/inquiries",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(data)});setState(r.ok?"done":"error")}
return <form className="form" onSubmit={submit}>{state==="done"&&<div className="notice">Thank you. Your enquiry has been received. We’ll contact you shortly.</div>}{state==="error"&&<div className="notice">Something went wrong. Please use WhatsApp or phone.</div>}
<div className="formGrid"><input name="name" placeholder="Your name" required/><input name="phone" placeholder="Phone / WhatsApp" required/></div>
<div className="formGrid"><input name="email" type="email" placeholder="Email (optional)"/><input name="product" defaultValue={product} placeholder="Product / service"/></div>
<div className="formGrid"><input name="quantity" placeholder="Quantity / size"/><select name="budget"><option value="">Budget range (optional)</option><option>Under ₹5,000</option><option>₹5,000–₹15,000</option><option>₹15,000–₹50,000</option><option>₹50,000+</option></select></div>
<textarea name="message" placeholder="Tell us what you need, including size, paper, finishing, delivery date, etc."/>
<button className="btn primary" disabled={state==="loading"}>{state==="loading"?"Sending…":"Send Enquiry"}</button></form>}