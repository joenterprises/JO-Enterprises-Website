# JO Enterprises — Full-Stack Website

A modern full-stack rebuild of the JO Enterprises Google Sites presence.

## What was studied

The source site presents JO Enterprises as a complete printing partner, with custom printing, branding, invitations, promotional products and a defined enquiry-to-delivery workflow. The Print Products page lists business cards, letterheads, bill books, envelopes, vouchers/receipts, files, wall posters, flyers/brochures, stickers, boxes/paper bags, calendars, non-woven bags, woven labels, novelties, graphic design and invitations.

The E-Cards page is currently empty, while Gallery currently shows "Under Construction" for photos/videos and links to WhatsApp, Facebook, Instagram, Google Business and YouTube. Contact information identifies Sivakasi as the printing hub and Muhavoor as the design desk.

## Stack

- Next.js App Router + TypeScript
- React
- Prisma ORM
- SQLite for local development
- API route for enquiries
- Responsive CSS
- Seeded product catalogue

## Run locally

1. Install Node.js 20+.
2. Copy `.env.example` to `.env`.
3. Run:
   ```bash
   npm install
   npx prisma db push
   npm run db:seed
   npm run dev
   ```
4. Open http://localhost:3000

## Production

For production, replace SQLite with PostgreSQL by changing `DATABASE_URL` and the Prisma datasource provider. Add proper authentication around `/admin`, configure email/WhatsApp notifications, and move product/gallery images to object storage or your CDN.

## Brand / content

The design uses a premium white + turquoise corporate palette with a darker teal accent and subtle gold detail. Product image URLs seeded from the original Google Sites assets are retained for the three available reference samples; replace them with local/CDN assets for long-term reliability.

## Main routes

- `/` Home
- `/print-products` Product catalogue
- `/e-cards` E-Cards
- `/gallery` Gallery/social
- `/contact` Contact + enquiry form
- `/admin` Enquiry dashboard
- `/api/inquiries` POST enquiry
- `/api/products` GET products
